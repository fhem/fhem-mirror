#ifndef __DHTxx__h
#define __DHTxx__h

#include <Arduino.h>

class DHTxx {
public:
  DHTxx();
  bool TryInitialize(byte pin, byte type = 22);
  bool TryMeasure();
  double GetTemperature();
  double GetHumidity();

private:
  byte m_pin;
  byte m_type;
  double m_humidity;
  double m_temperature;
  byte m_data[5];
  bool Read();
};
#endif
