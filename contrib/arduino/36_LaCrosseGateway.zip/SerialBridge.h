#ifndef _SERIALBRIDGE_H
#define _SERIALBRIDGE_H

#include "AddOnSerialBase.h"

typedef void ConnectCallbackType(bool isConnected);

class SerialBridge : public AddOnSerialBase {
public:
  SerialBridge(SC16IS750 *expander, byte dtrPort);
  void Begin(uint tcpPort, ESP8266WebServer *server);
  void Handle();
  void SetConnectCallback(ConnectCallbackType* callback);

private:
  uint m_tcpPort;
  WiFiServer m_wifiServer;
  WiFiClient m_client;
  bool m_isConnected;
  ConnectCallbackType *m_ConnectCallback;
};


#endif

