#include "ESP8266Tools.h"


ESP8266Tools::ESP8266Tools(byte ledPin) {
  m_ledPin = ledPin;
  m_ledEnabled = true;
}

void ESP8266Tools::SwitchLed(boolean on, bool force) {
  if (m_ledEnabled || force) {
    pinMode(m_ledPin, OUTPUT);
    digitalWrite(m_ledPin, !on);
  }
}

void ESP8266Tools::Blink(byte ct, bool force) {
  if (m_ledEnabled || force) {
    for (int i = 0; i < ct; i++) {
      SwitchLed(true, force);
      delay(5);
      SwitchLed(false, force);
      if (ct > 1) {
        delay(5);
      }
    }
  }

}

void ESP8266Tools::EnableLED(bool enable) {
  m_ledEnabled = enable;

  if (!m_ledEnabled) {
    SwitchLed(false);
  }

}

