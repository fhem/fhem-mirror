#ifndef _PCA301PLUGLIST_h
#define _PCA301PLUGLIST_h

#include "Arduino.h"
#include "HashMap.h"
#include "Settings.h"
#include "PCA301Plug.h"
#include <functional>

class PCA301PlugList{
public:
  typedef std::function<void(byte payload[10])> TCallbackFunction;
  typedef std::function<void(String)> TLogItemCallback;
  PCA301PlugList();
  void Begin(word pollInterval);
  void HandleReceivedPlug(byte id[3], byte channel);
  void Poll();
  byte GetNextFreeChannel();
  void OnSendPayload(TCallbackFunction fn);
  void SetLogItemCallback(TLogItemCallback callback);
  bool IsKnownPlug(byte id[3]);

protected:
  HashMap<String, PCA301Plug, 50> m_plugs;
  unsigned long m_lastPoll;
  word m_pollInterval;
  PCA301PlugList::TCallbackFunction m_sendPayloadCallback;
  PCA301PlugList::TLogItemCallback m_logItemCallback;
  void Log(String logItem);

};


#endif

