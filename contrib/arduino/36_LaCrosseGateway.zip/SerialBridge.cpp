#include "SerialBridge.h"

SerialBridge::SerialBridge(SC16IS750 *expander, byte dtrPort) : AddOnSerialBase(expander, dtrPort), m_wifiServer(0) {
  m_doLogging = true;
  m_ConnectCallback = nullptr;
}

void SerialBridge::Begin(uint tcpPort, ESP8266WebServer *server) {
  m_tcpPort = tcpPort;
  m_wifiServer = WiFiServer(m_tcpPort);
  m_server = server;

  AddOnSerialBase::Begin();

  m_wifiServer.begin();
  m_wifiServer.setNoDelay(true);
}

void SerialBridge::Handle() {
  if (m_wifiServer.hasClient()) {
    m_isConnected = true;
    m_client.stop();
    m_client = m_wifiServer.available();
    m_client.setNoDelay(true);
    Reset();
    delay(250);
   
    String logItem = "SerialBridge: #" + String(m_tcpPort) + " Client connected, IP=";
    logItem += m_client.remoteIP().toString();
    logItem += " Port=";
    logItem += m_client.remotePort();
    Log(logItem); 

    if (m_ConnectCallback) {
      m_ConnectCallback(true);
    }
  }
  if (!m_client.connected()) {
    if (m_isConnected) {
      m_ConnectCallback(false);
    }
    m_isConnected = false;
  }
 
  if (m_client.available()) {
    while (m_client.available()) {
      m_expander->Write(m_client.read());
    }
    delay(10);
  }
  

  byte len = m_expander->Available();
  if (len > 0) {
    byte buffer[len];
    for (byte b = 0; b < len; b++) {
      buffer[b] = m_expander->Read();
    }

    if (m_client && m_client.connected()) {
      m_client.write(buffer, len);
    }

  }

}

void SerialBridge::SetConnectCallback(ConnectCallbackType * callback) {
  m_ConnectCallback = callback;
}





